package org.cagrid.test.examplesdk1.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class ExampleSdkService1Impl extends ExampleSdkService1ImplBase {

	
	public ExampleSdkService1Impl() throws RemoteException {
		super();
	}
	
}

