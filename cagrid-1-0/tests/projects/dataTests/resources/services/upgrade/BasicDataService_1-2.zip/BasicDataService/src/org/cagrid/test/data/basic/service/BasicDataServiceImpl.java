package org.cagrid.test.data.basic.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class BasicDataServiceImpl extends BasicDataServiceImplBase {

	
	public BasicDataServiceImpl() throws RemoteException {
		super();
	}
	
}

