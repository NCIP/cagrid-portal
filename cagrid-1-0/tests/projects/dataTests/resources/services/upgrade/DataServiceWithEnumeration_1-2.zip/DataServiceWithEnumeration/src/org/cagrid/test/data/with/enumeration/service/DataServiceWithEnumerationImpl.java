package org.cagrid.test.data.with.enumeration.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class DataServiceWithEnumerationImpl extends DataServiceWithEnumerationImplBase {

	
	public DataServiceWithEnumerationImpl() throws RemoteException {
		super();
	}
	
}

