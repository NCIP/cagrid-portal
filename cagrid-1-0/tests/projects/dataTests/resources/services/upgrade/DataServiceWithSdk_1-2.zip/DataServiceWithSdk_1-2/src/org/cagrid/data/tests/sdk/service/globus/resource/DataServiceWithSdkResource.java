package org.cagrid.data.tests.sdk.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this DataServiceWithSdkResource type.
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class DataServiceWithSdkResource extends DataServiceWithSdkResourceBase {

}
