package org.cagrid.data.tests.sdk.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class DataServiceWithSdkImpl extends DataServiceWithSdkImplBase {

	
	public DataServiceWithSdkImpl() throws RemoteException {
		super();
	}
	
}

