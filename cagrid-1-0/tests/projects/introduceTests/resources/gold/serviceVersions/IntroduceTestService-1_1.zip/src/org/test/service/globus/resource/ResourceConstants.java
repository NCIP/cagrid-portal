package org.test.service.globus.resource;

import javax.xml.namespace.QName;


public interface ResourceConstants {
	public static final String SERVICE_NS = "http://test.org/IntroduceTestService";
	public static final QName RESOURCE_KEY = new QName(SERVICE_NS, "IntroduceTestServiceKey");
	public static final QName RESOURCE_PROPERTY_SET = new QName(SERVICE_NS, "IntroduceTestServiceResourceProperties");

	//Service level metadata (exposed as resouce properties)
	
}
