package org.test.context.service.globus.resource;

import org.globus.wsrf.ResourceException;

/** 
 * The implementation of this IntroduceTestServiceContextResource type.
 * 
 * @created by Introduce Toolkit version 1.1
 * 
 */
public class IntroduceTestServiceContextResource extends BaseResourceBase {


   	/**
	* This is the callback to destroy this resource. If anything needs to be cleaned up
	* when this resource is destroyed it should be done here.
	*/
    public void remove() throws ResourceException {
		// TODO Implement me
	}

}
