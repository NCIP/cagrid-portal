package gov.nih.nci.cagrid.metadata.exceptions;

/**
 * @author oster
 * 
 */
public class RemoteResourcePropertyRetrievalException extends ResourcePropertyRetrievalException {

	/**
	 * 
	 */
	public RemoteResourcePropertyRetrievalException() {
		super();
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param message
	 * @param cause
	 */
	public RemoteResourcePropertyRetrievalException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param message
	 */
	public RemoteResourcePropertyRetrievalException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param cause
	 */
	public RemoteResourcePropertyRetrievalException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
