package gov.nih.nci.cagrid.metadata.exceptions;

/**
 * @author oster
 * 
 */
public class ResourcePropertyRetrievalException extends Exception {

	/**
	 * 
	 */
	public ResourcePropertyRetrievalException() {
		super();
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param message
	 * @param cause
	 */
	public ResourcePropertyRetrievalException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param message
	 */
	public ResourcePropertyRetrievalException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param cause
	 */
	public ResourcePropertyRetrievalException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
