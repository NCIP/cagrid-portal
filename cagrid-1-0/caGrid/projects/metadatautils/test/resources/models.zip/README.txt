This zip file contains models for testing XMI to domain model conversion.  Each model, its gold domain model representation, and an info file reside in each subdirectory.


