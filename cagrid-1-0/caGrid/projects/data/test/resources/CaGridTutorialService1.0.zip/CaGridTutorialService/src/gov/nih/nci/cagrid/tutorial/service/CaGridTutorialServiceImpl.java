package gov.nih.nci.cagrid.tutorial.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.0
 * 
 */
public class CaGridTutorialServiceImpl extends CaGridTutorialServiceImplBase {

	
	public CaGridTutorialServiceImpl() throws RemoteException {
		super();
	}
	
	public gov.nih.nci.cabio.domain.Gene[] findGenesSharePathways(gov.nih.nci.cabio.domain.Gene gene) throws RemoteException {

try {
			String caBioURL;
			try {
				caBioURL = getConfiguration()
						.getCqlQueryProcessorConfig_appserviceUrl();
			} catch (Exception e) {
				throw new RemoteException(
						"Unable to load service configuration");
			}
			gov.nih.nci.system.applicationservice.ApplicationService appService = gov.nih.nci.system.applicationservice.ApplicationService
					.getRemoteInstance(caBioURL);

			String gClass = gov.nih.nci.cabio.domain.Gene.class.getName();
			String hql = "SELECT DISTINCT g2 FROM "
					+ gClass
					+ " as g1, "
					+ gClass
					+ " as g2 WHERE g1.symbol='"
					+ gene.getSymbol()
					+ "' AND g2.pathwayCollection.id IN g1.pathwayCollection.id";
			java.util.List rList = appService.query(
					new gov.nih.nci.common.util.HQLCriteria(hql),
					gov.nih.nci.cabio.domain.Gene.class.getName());
			gov.nih.nci.cabio.domain.Gene[] geneArray = new gov.nih.nci.cabio.domain.Gene[rList
					.size()];
			System.arraycopy(rList.toArray(), 0, geneArray, 0, rList.size());
			return geneArray;
		} catch (gov.nih.nci.system.applicationservice.ApplicationException e) {
			e.printStackTrace();
			throw new RemoteException("Error trying to find shared pathways");
		}
	}

}

