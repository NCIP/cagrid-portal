package gov.nih.nci.cagrid.basicdataservice.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.0
 * 
 */
public class BasicDataServiceImpl extends BasicDataServiceImplBase {

	
	public BasicDataServiceImpl() throws RemoteException {
		super();
	}
	
}

