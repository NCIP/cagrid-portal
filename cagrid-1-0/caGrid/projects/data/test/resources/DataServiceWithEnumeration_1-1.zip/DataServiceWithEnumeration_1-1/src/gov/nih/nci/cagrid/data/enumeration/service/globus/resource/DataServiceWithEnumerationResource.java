package gov.nih.nci.cagrid.data.enumeration.service.globus.resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** 
 * The implementation of this DataServiceWithEnumerationResource type.
 * 
 * @created by Introduce Toolkit version 1.1
 * 
 */
public class DataServiceWithEnumerationResource extends BaseResourceBase {



}
