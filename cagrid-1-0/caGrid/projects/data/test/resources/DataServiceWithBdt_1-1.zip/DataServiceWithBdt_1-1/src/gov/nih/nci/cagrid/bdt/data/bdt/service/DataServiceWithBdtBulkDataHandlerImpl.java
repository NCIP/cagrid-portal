package gov.nih.nci.cagrid.bdt.data.bdt.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.1
 * 
 */
public class DataServiceWithBdtBulkDataHandlerImpl extends DataServiceWithBdtBulkDataHandlerImplBase {

	
	public DataServiceWithBdtBulkDataHandlerImpl() throws RemoteException {
		super();
	}
	
}

