package gov.nih.nci.cagrid.bdt.data.service;

import gov.nih.nci.cagrid.bdt.service.globus.resource.BDTResourceBase;
import gov.nih.nci.cagrid.bdt.service.globus.resource.BDTResourceI;
import gov.nih.nci.cagrid.bdt.service.globus.resource.BDTException;

import org.globus.transfer.AnyXmlType;
import org.globus.ws.enumeration.EnumIterator;
import org.globus.wsrf.ResourceException;

/**
* BDTResource is to represent the backend resource that will be persisted during this 
* transfer of data to the callers. It is expected that the creator of this class will
* implement at least the createEnumeration get methods and may add other mechanisms 
* for transfer.  
*/
public class BDTResource extends BDTResourceBase implements BDTResourceI {
private gov.nih.nci.cagrid.data.bdt.service.BDTResourceHelper helper;

	/**
	* This method will create a WS-Enumeration EnumIterator  Once this Iterator is created
	* the client will be able to use it to iterate through the results.
	*/
	public EnumIterator createEnumeration() throws BDTException {
	  	try {
		return helper.createEnumIterator();
	} catch (gov.nih.nci.cagrid.data.faults.QueryProcessingExceptionType ex) {
		throw new BDTException("Error processing query: " + ex.getMessage(), ex);
	} catch (gov.nih.nci.cagrid.data.faults.MalformedQueryExceptionType ex) {
		throw new BDTException("Improperly formed query: " + ex.getMessage(), ex);
	}
}
	
	/**
	* This method will return the results as an XMLAnyType.  Essentially an XML blob.
	*/
	public AnyXmlType get() throws BDTException {
	  	try {
		return helper.resultsAsAnyType();
	} catch (gov.nih.nci.cagrid.data.QueryProcessingException ex) {
		throw new BDTException("Error processing query: " + ex.getMessage(), ex);
	} catch (gov.nih.nci.cagrid.data.MalformedQueryException ex) {
		throw new BDTException("Improperly formed query: " + ex.getMessage(), ex);
	}
}
	
	/**
	* This will return the results as a staged set of GridFTP URLS which can then be
	* retieved using GridFTP client.
	*/
	public org.apache.axis.types.URI[] getGridFTPURLs() throws BDTException {
	  //TODO: Implement me
	  throw new BDTException("\"getGridFTPURLs()\" not yet implemented");
    }
    
   	/**
	* This is the callback to destroy this resource. If anything needs to be cleaned up
	* when this resource is destroyed it should be done here.
	*/
    public void remove() throws ResourceException {
			helper.cleanUp();

	}
    
	void initialize(gov.nih.nci.cagrid.cqlquery.CQLQuery query, 
			String classToQnameMapfile, 
			java.io.InputStream wsddStream) throws java.rmi.RemoteException, gov.nih.nci.cagrid.data.service.DataServiceInitializationException {
		this.helper = new gov.nih.nci.cagrid.data.bdt.service.BDTResourceHelper(
			query, classToQnameMapfile, wsddStream);
	}
}
