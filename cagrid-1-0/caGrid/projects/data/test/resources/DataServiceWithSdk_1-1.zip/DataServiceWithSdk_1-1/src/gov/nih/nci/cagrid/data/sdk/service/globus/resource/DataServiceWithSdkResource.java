package gov.nih.nci.cagrid.data.sdk.service.globus.resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** 
 * The implementation of this DataServiceWithSdkResource type.
 * 
 * @created by Introduce Toolkit version 1.1
 * 
 */
public class DataServiceWithSdkResource extends BaseResourceBase {



}
