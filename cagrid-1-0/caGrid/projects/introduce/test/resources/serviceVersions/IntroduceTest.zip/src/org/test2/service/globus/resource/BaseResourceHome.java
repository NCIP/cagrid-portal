package org.test2.service.globus.resource;

import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;
import org.globus.wsrf.impl.ResourceHomeImpl;
import org.globus.wsrf.impl.SimpleResourceKey;
import org.apache.axis.message.addressing.EndpointReferenceType;
import org.apache.axis.MessageContext;
import org.globus.wsrf.utils.AddressingUtils;

/**
 * This class implements a resource home
 */

public class BaseResourceHome extends ResourceHomeImpl {

	/**
 	* Creates a new Resource, adds it to the list of resources managed by this resource home,
 	* and returns the key to the resource.
 	*/
	public ResourceKey createResource() throws Exception {
		// Create a resource and initialize it
		BaseResource resource = (BaseResource) createNewInstance();
		resource.initialize();

		// Get key
		ResourceKey key = new SimpleResourceKey(getKeyTypeName(), resource.getID());
		
		// Add the resource to the list of resources in this home
		add(key, resource);
		return key;
	}
	
	/**
 	* Take a resource key managed by this resource, locates the resource, and created a typed EPR for the resource.
 	*/
	public org.test2.stubs.types.IntroduceTestServiceInnerServiceReference getResourceReference(ResourceKey key) throws Exception {
		MessageContext ctx = MessageContext.getCurrentContext();
		String transportURL = (String) ctx.getProperty(org.apache.axis.MessageContext.TRANS_URL);
		transportURL = transportURL.substring(0,transportURL.lastIndexOf('/') +1 );
		transportURL += "IntroduceTestServiceInnerService";
		EndpointReferenceType epr = AddressingUtils.createEndpointReference(transportURL,key);
		org.test2.stubs.types.IntroduceTestServiceInnerServiceReference ref = new org.test2.stubs.types.IntroduceTestServiceInnerServiceReference();
		ref.setEndpointReference(epr);
		return ref;
	}

	/**
 	* Given the key of a resource managed by this resource home, a type resource will be returned.
 	*/	
	public BaseResource getResource(ResourceKey key) throws ResourceException {
		BaseResource thisResource = (BaseResource)find(key);
		return thisResource;
	}
	
	
	
}