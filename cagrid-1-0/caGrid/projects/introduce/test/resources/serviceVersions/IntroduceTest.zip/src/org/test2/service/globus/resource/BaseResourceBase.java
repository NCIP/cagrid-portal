package org.test2.service.globus.resource;

import java.util.Calendar;

import org.globus.wsrf.Resource;
import org.globus.wsrf.ResourceIdentifier;
import org.globus.wsrf.RemoveCallback;
import org.globus.wsrf.jndi.Initializable;

import org.apache.axis.components.uuid.UUIDGenFactory;
import org.apache.axis.components.uuid.UUIDGen;

public abstract class BaseResourceBase implements Resource, RemoveCallback, ResourceIdentifier, Initializable {

	/** the identifier of this resource... should be unique in the service */
	private Object id;
	private static final UUIDGen UUIDGEN = UUIDGenFactory.getUUIDGen();


	/**
	 * @see org.globus.wsrf.ResourceIdentifier#getID()
	 */
	public Object getID() {
		return this.id;
	}


	/**
	 * @see org.globus.wsrf.jndi.Initializable#initialize()
	 */
	public final void initialize() throws Exception {
		this.id = UUIDGEN.nextUUID();
	}
	

}
