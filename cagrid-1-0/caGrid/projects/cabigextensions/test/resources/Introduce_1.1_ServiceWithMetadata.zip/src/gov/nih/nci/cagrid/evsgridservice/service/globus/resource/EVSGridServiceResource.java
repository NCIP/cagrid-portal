package gov.nih.nci.cagrid.evsgridservice.service.globus.resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** 
 * The implementation of this EVSGridServiceResource type.
 * 
 * @created by Introduce Toolkit version 1.1
 * 
 */
public class EVSGridServiceResource extends BaseResourceBase {



}
