package gov.nih.nci.system.security;


public class SecurityConstants {
	public static String CREATE = "CREATE";
	public static String ACCESS = "ACCESS";
	public static String READ = "READ";
	public static String WRITE = "WRITE";
	public static String UPDATE = "UPDATE";
	public static String DELETE = "DELETE";
	public static String DUMMY_ROLE = "DUMMYROLE";
}