package gov.nih.nci.system.dao;

public interface WritableDAO extends DAO
{
}
