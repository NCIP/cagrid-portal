package gov.nih.nci.system.query.example;


public class DeleteExampleQuery extends ExampleQuery implements ExampleManipulationQuery
{
	private static final long serialVersionUID = 1L;

	public DeleteExampleQuery(Object example) {
		super(example);
	}
}